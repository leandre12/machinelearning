import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
import seaborn as sns
import pandas as pd
from scipy.cluster.hierarchy import dendrogram
import os
from datetime import *

def getNbDays(start, end, datetimeFormat):
    try :
        diffDays = (datetime.strptime(end, datetimeFormat) - datetime.strptime(start, datetimeFormat)).days
        return diffDays
    except ValueError:
        return -1

def setCategoriesData():
    product_categories_dict = {
        'construction_tools_construction': 'construction',
        'construction_tools_lights': 'construction',
        'construction_tools_safety': 'construction',
        'costruction_tools_garden': 'construction',
        'costruction_tools_tools': 'construction',
        'garden_tools': 'construction',
        'home_construction': 'construction',

        'fashio_female_clothing': 'fashion',
        'fashion_bags_accessories': 'fashion',
        'fashion_childrens_clothes': 'fashion',
        'fashion_male_clothing': 'fashion',
        'fashion_shoes': 'fashion',
        'fashion_sport': 'fashion',
        'fashion_underwear_beach': 'fashion',

        'furniture_bedroom': 'furniture',
        'furniture_decor': 'furniture',
        'furniture_living_room': 'furniture',
        'furniture_mattress_and_upholstery': 'furniture',
        'bed_bath_table': 'furniture',
        'kitchen_dining_laundry_garden_furniture': 'furniture',
        'office_furniture': 'furniture',

        'home_appliances': 'home',
        'home_appliances_2': 'home',
        'home_comfort_2': 'home',
        'home_confort': 'home',
        'air_conditioning': 'home',
        'housewares': 'home',
        'art': 'home',
        'arts_and_craftmanship': 'home',
        'flowers': 'home',
        'cool_stuff': 'home',

        'drinks': 'food_drink',
        'food': 'food_drink',
        'food_drink': 'food_drink',
        'la_cuisine': 'food_drink',

        'electronics': 'electronics',
        'audio': 'electronics',
        'tablets_printing_image': 'electronics',
        'telephony': 'electronics',
        'fixed_telephony': 'electronics',
        'small_appliances': 'electronics',
        'small_appliances_home_oven_and_coffee': 'electronics',
        'computers_accessories': 'electronics',
        'computers': 'electronics',
        'sports_leisure': 'sports_leisure',
        'consoles_games': 'sports_leisure',
        'musical_instruments': 'sports_leisure',
        'toys': 'sports_leisure',
        'cine_photo': 'sports_leisure',
        'dvds_blu_ray': 'sports_leisure',
        'cds_dvds_musicals': 'sports_leisure',
        'music': 'sports_leisure',
        'books_general_interest': 'sports_leisure',
        'books_imported': 'sports_leisure',
        'books_technical': 'sports_leisure',

        'health_beauty': 'health_beauty',
        'perfumery': 'health_beauty',
        'diapers_and_hygiene': 'health_beauty',
        'baby': 'health_beauty',

        'christmas_supplies': 'supplies',
        'stationery': 'supplies',
        'party_supplies': 'supplies',
        'auto': 'supplies',
        'luggage_accessories': 'supplies',

        'watches_gifts': 'gifts',

        'agro_industry_and_commerce': 'misc',
        'industry_commerce_and_business': 'misc',
        'security_and_services': 'misc',
        'signaling_and_security': 'misc',
        'market_place': 'misc',
        'pet_shop': 'misc',
    }
    dfCaregories = pd.DataFrame(list(product_categories_dict.items()), columns=['category', 'product_category_group'])
    return dfCaregories

def getCategoriesGroup(cat_dict,cat_name):
    cat_group = cat_dict[cat_name]

    return cat_group